package com.stockcharting;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StockChartingCompaniesApplicationTests {

	@Test
	public void contextLoads() throws URISyntaxException {
		
		RestTemplate resttemplate = new RestTemplate();
		final String baseUrl = "http://localhost:8990/companies";
		 URI uri = new URI(baseUrl);
		 
		 ResponseEntity<String> result =resttemplate.getForEntity(uri, String.class);
		 
		 Assert.assertEquals(200, result.getStatusCodeValue());
				
	}

}
